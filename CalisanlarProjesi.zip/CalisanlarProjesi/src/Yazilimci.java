/**
 *
 * @author tugba
 */
public class Yazilimci extends Calisan
{
    private String bildigi_diller;
    public Yazilimci(String ad, String soyad, int id, String diller)
    {
        super(ad,soyad,id);
        this.bildigi_diller = bildigi_diller;
    }
    
    public void formatAt(String isletim_sistemi)
    {
        System.out.println(getAd() + " " + isletim_sistemi + "ni yüklüyor..." );
    }

    @Override
    public void bilgileriGoster() 
    {
        super.bilgileriGoster();
        System.out.println("Yazılımcının bildiği diller: " + bildigi_diller);
    }
    
    
}
