/**
 *
 * @author tugba
 */
public class Yonetici extends Calisan
{
    private int sorumlu_kisi_sayisi;
    
    public Yonetici(String ad, String Soyad, int id, int sorumlu_kisi_sayisi)
    {
        super(ad, Soyad, id);
        this.sorumlu_kisi_sayisi = sorumlu_kisi_sayisi;
    }
    
    public void bilgileriGoster()
    {
        super.bilgileriGoster();
        System.out.println("Yöneticinin sorumlu olduğu kişi sayısı: " + sorumlu_kisi_sayisi);
    }
    
    public void zamYap(int zam_miktari)
    {
        System.out.println(getAd() + " çalışanlara " + zam_miktari + " kadar zam yapıyor...");
    }
}
